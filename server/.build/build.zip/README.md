
## Launch graphcool in the console

###


### go to the url
`https://console.graph.cool/Example%20Project/schema/types`